﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace StateManagement
{
    public partial class Page1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (ViewState["clicks"] != null)
            {
                ViewState["clicks"] = (int)ViewState["clicks"] + 1;
            }
            else
            {
                ViewState["clicks"] = 1;
            }
            lbldisplay.Text = " ViewState clicks: " + ((int)ViewState["clicks"]).ToString();
            //{
            //    int clicks;
            //    int.TryParse(HiddenField1.Value, out clicks);
            //    clicks++;
            //    HiddenField1.Value = clicks.ToString();
            //    lbldisplay.Text = "HiddenField clicks: " + HiddenField1.Value;

        }

        protected void Button1_Click(object sender, EventArgs e)
        {

        }

        
      
    }
}